#ifndef _LED_DRIVER_H
#define _LED_DRIVER_H

void led_init(void);
void led_on(void);
void led_off(void);
void led_toggle(void);

#endif
