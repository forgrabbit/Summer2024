#ifndef _TIM_DRIVER_H
#define _TIM_DRIVER_H

#include "main.h"

void Timer_Init(void);

#endif
